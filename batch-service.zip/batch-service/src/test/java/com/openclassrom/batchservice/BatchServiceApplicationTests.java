package com.openclassrom.batchservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BatchServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
